import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { FileSpreadsheet, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface UploadZoneProps {
  onFileUploaded: (jobId: number) => void;
}

export function UploadZone({ onFileUploaded }: UploadZoneProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [hasHeader, setHasHeader] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = (file: File) => {
    if (!file.name.endsWith('.csv')) {
      toast({
        title: "Invalid file type",
        description: "Please select a CSV file.",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "File size must be less than 10MB.",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleStartVerification = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const formData = new FormData();
      formData.append('csvFile', selectedFile);
      formData.append('hasHeader', hasHeader.toString());

      const response = await fetch('/api/jobs/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Upload failed');
      }

      const result = await response.json();
      
      toast({
        title: "Upload successful",
        description: "Your file is being processed. You can view the results in the Results tab.",
      });

      onFileUploaded(result.jobId);
      
      // Reset form
      setSelectedFile(null);
      setHasHeader(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-brand rounded-full flex items-center justify-center mx-auto mb-4">
              <Upload className="text-white text-2xl" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Upload CSV File</h3>
            <p className="text-gray-600">Upload your CSV file containing email addresses for verification</p>
          </div>

          {!selectedFile ? (
            <div 
              className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-brand transition-colors duration-200 cursor-pointer"
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onClick={handleBrowseClick}
            >
              <div className="space-y-4">
                <FileSpreadsheet className="w-16 h-16 text-gray-400 mx-auto" />
                <div>
                  <p className="text-lg font-medium text-gray-900 mb-1">Drop your CSV file here</p>
                  <p className="text-gray-500">or <span className="text-brand hover:text-blue-600 font-medium">browse to choose a file</span></p>
                </div>
                <div className="text-sm text-gray-500">
                  <p>Supported format: CSV</p>
                  <p>Maximum file size: 10MB</p>
                </div>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".csv"
                onChange={handleFileInputChange}
              />
            </div>
          ) : (
            <div className="border-2 border-green-300 bg-green-50 rounded-xl p-8 text-center">
              <div className="space-y-4">
                <FileSpreadsheet className="w-16 h-16 text-green-600 mx-auto" />
                <div>
                  <p className="text-lg font-medium text-gray-900">{selectedFile.name}</p>
                  <p className="text-gray-500">{formatFileSize(selectedFile.size)} • Ready to verify</p>
                </div>
                <Button variant="outline" onClick={() => setSelectedFile(null)}>
                  Choose different file
                </Button>
              </div>
            </div>
          )}

          {isUploading && (
            <div className="mt-6">
              <Progress value={uploadProgress} className="mb-2" />
              <div className="flex justify-between text-sm text-gray-600">
                <span>Uploading...</span>
                <span>{uploadProgress}%</span>
              </div>
            </div>
          )}

          <div className="mt-8 space-y-4">
            <Card className="bg-gray-50">
              <CardContent className="p-4">
                <h4 className="font-medium text-gray-900 mb-2">CSV Format Requirements:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• First column should contain email addresses</li>
                  <li>• Header row is optional but recommended</li>
                  <li>• Each email should be on a separate row</li>
                  <li>• UTF-8 encoding is preferred</li>
                </ul>
              </CardContent>
            </Card>

            <div className="flex items-center justify-between pt-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="hasHeader" 
                  checked={hasHeader}
                  onCheckedChange={setHasHeader}
                />
                <label htmlFor="hasHeader" className="text-sm text-gray-700">
                  File has header row
                </label>
              </div>
              <Button 
                className="bg-brand hover:bg-blue-600"
                disabled={!selectedFile || isUploading}
                onClick={handleStartVerification}
              >
                <Upload className="w-4 h-4 mr-2" />
                Start Verification
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
