import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  change?: {
    value: string;
    label: string;
    positive?: boolean;
  };
  iconColor: string;
  iconBgColor: string;
}

export function StatsCard({ 
  title, 
  value, 
  icon: Icon, 
  change, 
  iconColor, 
  iconBgColor 
}: StatsCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
            <p className="text-2xl font-bold text-gray-900">
              {typeof value === 'number' ? value.toLocaleString() : value}
            </p>
          </div>
          <div className={`w-12 h-12 ${iconBgColor} rounded-lg flex items-center justify-center`}>
            <Icon className={`${iconColor} text-xl`} />
          </div>
        </div>
        {change && (
          <div className="mt-4 flex items-center text-sm">
            <span className={`font-medium ${change.positive !== false ? 'text-green-600' : 'text-red-600'}`}>
              {change.value}
            </span>
            <span className="text-gray-500 ml-2">{change.label}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
