import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Search, Download, CheckCircle, XCircle, ChevronLeft, ChevronRight, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface VerificationResult {
  id: number;
  email: string;
  isValid: boolean;
  reason: string;
  domain: string | null;
  mxRecord?: string | null;
  deliverable?: boolean | null;
  verifiedAt: string;
}

interface VerificationTableProps {
  jobId: number;
  results: VerificationResult[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
  onPageChange: (page: number) => void;
}

export function VerificationTable({ jobId, results, pagination, onPageChange }: VerificationTableProps) {
  const [selectedResults, setSelectedResults] = useState<Set<number>>(new Set());
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const { toast } = useToast();

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedResults(new Set(results.map(r => r.id)));
    } else {
      setSelectedResults(new Set());
    }
  };

  const handleSelectResult = (id: number, checked: boolean) => {
    const newSelected = new Set(selectedResults);
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedResults(newSelected);
  };

  const handleExport = async (validOnly?: boolean) => {
    try {
      const url = validOnly 
        ? `/api/jobs/${jobId}/export?validOnly=true`
        : `/api/jobs/${jobId}/export`;
      
      const response = await fetch(url, {
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Export failed');
      }

      // Create download link
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `verification_results_${jobId}_${validOnly ? 'valid' : 'all'}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);

      toast({
        title: "Export successful",
        description: "Your verification results have been downloaded.",
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Failed to export verification results.",
        variant: "destructive",
      });
    }
  };

  const filteredResults = results.filter(result => {
    const matchesSearch = result.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "valid" && result.isValid) ||
      (statusFilter === "invalid" && !result.isValid);
    
    return matchesSearch && matchesStatus;
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <div className="space-y-6">
      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search emails..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="valid">Valid</SelectItem>
                <SelectItem value="invalid">Invalid</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center space-x-3">
            <Button 
              variant="outline"
              onClick={() => handleExport(true)}
            >
              <Download className="w-4 h-4 mr-2" />
              Export Valid
            </Button>
            <Button 
              variant="outline"
              onClick={() => handleExport(false)}
            >
              <Download className="w-4 h-4 mr-2" />
              Export Invalid
            </Button>
            <Button 
              className="bg-brand hover:bg-blue-600"
              onClick={() => handleExport()}
            >
              <Download className="w-4 h-4 mr-2" />
              Export All
            </Button>
          </div>
        </div>
      </div>

      {/* Results Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Verification Results</h3>
            <div className="flex items-center space-x-4 text-sm">
              <span className="text-gray-500">
                Showing {((pagination.page - 1) * pagination.limit) + 1}-{Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total} results
              </span>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">
                  <Checkbox
                    checked={selectedResults.size === filteredResults.length && filteredResults.length > 0}
                    onCheckedChange={handleSelectAll}
                  />
                </TableHead>
                <TableHead>Email Address</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Domain</TableHead>
                <TableHead>Deliverable</TableHead>
                <TableHead>MX Record</TableHead>
                <TableHead>Verified At</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredResults.map((result) => (
                <TableRow key={result.id}>
                  <TableCell>
                    <Checkbox
                      checked={selectedResults.has(result.id)}
                      onCheckedChange={(checked) => handleSelectResult(result.id, checked as boolean)}
                    />
                  </TableCell>
                  <TableCell className="font-medium">{result.email}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={result.isValid ? "default" : "destructive"}
                      className={result.isValid ? "bg-green-100 text-green-800 hover:bg-green-200" : ""}
                    >
                      {result.isValid ? (
                        <CheckCircle className="w-3 h-3 mr-1" />
                      ) : (
                        <XCircle className="w-3 h-3 mr-1" />
                      )}
                      {result.isValid ? "Valid" : "Invalid"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-gray-600">{result.reason}</TableCell>
                  <TableCell>{result.domain || "-"}</TableCell>
                  <TableCell>
                    {result.deliverable ? (
                      <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                        <Mail className="w-3 h-3 mr-1" />
                        Deliverable
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-gray-600">
                        <XCircle className="w-3 h-3 mr-1" />
                        Not Deliverable
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-gray-600 font-mono text-xs">
                    {result.mxRecord || "-"}
                  </TableCell>
                  <TableCell className="text-gray-500">{formatDate(result.verifiedAt)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <div className="px-6 py-4 border-t border-gray-200">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-500">
              Showing <span className="font-medium">{(pagination.page - 1) * pagination.limit + 1}</span> to{" "}
              <span className="font-medium">{Math.min(pagination.page * pagination.limit, pagination.total)}</span> of{" "}
              <span className="font-medium">{pagination.total}</span> results
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onPageChange(pagination.page - 1)}
                disabled={pagination.page <= 1}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              
              {Array.from({ length: Math.min(5, pagination.pages) }, (_, i) => {
                const page = i + 1;
                return (
                  <Button
                    key={page}
                    variant={page === pagination.page ? "default" : "outline"}
                    size="sm"
                    onClick={() => onPageChange(page)}
                    className={page === pagination.page ? "bg-brand hover:bg-blue-600" : ""}
                  >
                    {page}
                  </Button>
                );
              })}
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => onPageChange(pagination.page + 1)}
                disabled={pagination.page >= pagination.pages}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
