import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { Plus } from "lucide-react";

interface TopbarProps {
  title: string;
  description: string;
}

export function Topbar({ title, description }: TopbarProps) {
  const { user } = useAuth();

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-8 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
          <p className="text-gray-600 mt-1">{description}</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="bg-gray-100 px-4 py-2 rounded-lg">
            <span className="text-sm text-gray-600">Credits remaining: </span>
            <span className="font-bold text-gray-900">{user?.credits?.toLocaleString() || 0}</span>
          </div>
          <Button className="bg-brand hover:bg-blue-600">
            <Plus className="w-4 h-4 mr-2" />
            Buy Credits
          </Button>
        </div>
      </div>
    </header>
  );
}
