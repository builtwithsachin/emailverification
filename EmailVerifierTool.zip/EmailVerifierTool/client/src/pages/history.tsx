import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Topbar } from "@/components/layout/topbar";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Download,
  Eye,
  Trash2,
  FileSpreadsheet
} from "lucide-react";
import { Link } from "wouter";

export default function History() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/jobs"],
    enabled: isAuthenticated,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    }
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
            Completed
          </Badge>
        );
      case 'processing':
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
            Processing
          </Badge>
        );
      case 'failed':
        return (
          <Badge variant="destructive">
            Failed
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">
            {status}
          </Badge>
        );
    }
  };

  const getValidationRate = (job: any) => {
    if (!job.totalEmails || job.totalEmails === 0) return 0;
    return ((job.validEmails || 0) / job.totalEmails * 100);
  };

  const handleDownload = (jobId: number) => {
    window.open(`/api/jobs/${jobId}/export`, '_blank');
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 p-8">
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex space-x-4 items-center">
                    <Skeleton className="h-4 w-4" />
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Topbar 
        title="Verification History" 
        description="Browse your verification history" 
      />

      <main className="flex-1 overflow-auto p-8">
        <div className="space-y-6">
          <Card>
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Verification History</h3>
                <div className="flex items-center space-x-3">
                  <Select defaultValue="30">
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">Last 30 Days</SelectItem>
                      <SelectItem value="90">Last 90 Days</SelectItem>
                      <SelectItem value="365">Last Year</SelectItem>
                      <SelectItem value="all">All Time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>File Name</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Total Processed</TableHead>
                    <TableHead>Valid Rate</TableHead>
                    <TableHead>Credits Used</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {jobsLoading ? (
                    [...Array(5)].map((_, i) => (
                      <TableRow key={i}>
                        <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                        <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      </TableRow>
                    ))
                  ) : jobs?.length ? (
                    jobs.map((job: any) => {
                      const validationRate = getValidationRate(job);
                      
                      return (
                        <TableRow key={job.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <FileSpreadsheet className="text-green-600 mr-3 w-4 h-4" />
                              <span className="text-sm font-medium text-gray-900">
                                {job.originalFileName}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>{getStatusBadge(job.status)}</TableCell>
                          <TableCell className="text-sm text-gray-900">{job.totalEmails || 0}</TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <span className="text-sm font-medium text-gray-900 min-w-[3rem]">
                                {validationRate.toFixed(1)}%
                              </span>
                              <div className="w-16 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-green-500 h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${validationRate}%` }}
                                />
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-gray-900">{job.creditsUsed || 0}</TableCell>
                          <TableCell className="text-sm text-gray-500">{formatDate(job.createdAt)}</TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              {job.status === 'completed' && (
                                <>
                                  <Link href={`/results?jobId=${job.id}`}>
                                    <Button variant="ghost" size="sm" className="text-brand hover:text-blue-600">
                                      <Eye className="w-4 h-4 mr-1" />
                                      View Results
                                    </Button>
                                  </Link>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    className="text-brand hover:text-blue-600"
                                    onClick={() => handleDownload(job.id)}
                                  >
                                    <Download className="w-4 h-4 mr-1" />
                                    Download
                                  </Button>
                                </>
                              )}
                              {job.status === 'processing' && (
                                <span className="text-sm text-gray-400">Processing...</span>
                              )}
                              {job.status === 'failed' && (
                                <span className="text-sm text-red-500">Failed</span>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-12">
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <FileSpreadsheet className="w-8 h-8 text-gray-400" />
                        </div>
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No verification history</h3>
                        <p className="text-gray-600 mb-4">
                          You haven't processed any CSV files yet.
                        </p>
                        <Link href="/upload">
                          <Button className="bg-brand hover:bg-blue-600">
                            Upload Your First CSV
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
