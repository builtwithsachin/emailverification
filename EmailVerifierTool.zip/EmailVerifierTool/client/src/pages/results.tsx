import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Topbar } from "@/components/layout/topbar";
import { VerificationTable } from "@/components/ui/verification-table";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

export default function Results() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);
  const [currentPage, setCurrentPage] = useState(1);

  // Get jobId from URL params if provided
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const jobIdParam = urlParams.get('jobId');
    if (jobIdParam) {
      setSelectedJobId(parseInt(jobIdParam));
    }
  }, []);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch user's verification jobs
  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/jobs"],
    enabled: isAuthenticated,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    }
  });

  // Fetch results for selected job
  const { data: resultsData, isLoading: resultsLoading } = useQuery({
    queryKey: ["/api/jobs", selectedJobId, "results", { page: currentPage }],
    queryFn: async () => {
      if (!selectedJobId) return null;
      const response = await fetch(`/api/jobs/${selectedJobId}/results?page=${currentPage}&limit=50`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to fetch results');
      }
      return response.json();
    },
    enabled: isAuthenticated && !!selectedJobId,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    }
  });

  // Auto-select first completed job if none selected
  useEffect(() => {
    if (jobs && !selectedJobId) {
      const completedJobs = jobs.filter((job: any) => job.status === 'completed');
      if (completedJobs.length > 0) {
        setSelectedJobId(completedJobs[0].id);
      }
    }
  }, [jobs, selectedJobId]);

  const handleJobChange = (jobId: string) => {
    setSelectedJobId(parseInt(jobId));
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 p-8">
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <Skeleton className="h-4 w-48 mb-4" />
                <Skeleton className="h-10 w-64" />
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex space-x-4">
                      <Skeleton className="h-4 w-4" />
                      <Skeleton className="h-4 w-48" />
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  const completedJobs = jobs?.filter((job: any) => job.status === 'completed') || [];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Topbar 
        title="Verification Results" 
        description="View and manage verification results" 
      />

      <main className="flex-1 overflow-auto p-8">
        <div className="space-y-6">
          {/* Job Selection */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Select Verification Job</h3>
                  <p className="text-gray-600">Choose a completed verification job to view results</p>
                </div>
                <div className="w-80">
                  <Select
                    value={selectedJobId?.toString() || ""}
                    onValueChange={handleJobChange}
                    disabled={jobsLoading || completedJobs.length === 0}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a verification job" />
                    </SelectTrigger>
                    <SelectContent>
                      {completedJobs.map((job: any) => (
                        <SelectItem key={job.id} value={job.id.toString()}>
                          <div className="flex flex-col items-start">
                            <span className="font-medium">{job.originalFileName}</span>
                            <span className="text-sm text-gray-500">
                              {job.totalEmails} emails • {new Date(job.completedAt).toLocaleDateString()}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Results Table */}
          {selectedJobId && resultsData ? (
            <VerificationTable
              jobId={selectedJobId}
              results={resultsData.results}
              pagination={resultsData.pagination}
              onPageChange={handlePageChange}
            />
          ) : selectedJobId && resultsLoading ? (
            <Card>
              <CardContent className="p-6">
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand mx-auto mb-4"></div>
                  <p className="text-gray-600">Loading verification results...</p>
                </div>
              </CardContent>
            </Card>
          ) : completedJobs.length === 0 ? (
            <Card>
              <CardContent className="p-6">
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No completed verification jobs</h3>
                  <p className="text-gray-600 mb-4">
                    Upload and process a CSV file to see verification results here.
                  </p>
                  <a 
                    href="/upload" 
                    className="inline-flex items-center px-4 py-2 bg-brand text-white rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    Upload CSV File
                  </a>
                </div>
              </CardContent>
            </Card>
          ) : null}
        </div>
      </main>
    </div>
  );
}
