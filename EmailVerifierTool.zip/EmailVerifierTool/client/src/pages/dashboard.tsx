import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Topbar } from "@/components/layout/topbar";
import { StatsCard } from "@/components/ui/stats-card";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Mail, 
  CheckCircle, 
  XCircle, 
  FileText,
  Download,
  Trash2,
  FileSpreadsheet
} from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    enabled: isAuthenticated,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    }
  });

  const { data: recentJobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/jobs/recent"],
    enabled: isAuthenticated,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    }
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
            Completed
          </Badge>
        );
      case 'processing':
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
            Processing
          </Badge>
        );
      case 'failed':
        return (
          <Badge variant="destructive">
            Failed
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">
            {status}
          </Badge>
        );
    }
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 p-8">
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <Skeleton className="h-4 w-24 mb-2" />
                    <Skeleton className="h-8 w-16 mb-4" />
                    <Skeleton className="h-4 w-20" />
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Topbar 
        title="Dashboard" 
        description="Overview of your email verification activities" 
      />

      <main className="flex-1 overflow-auto p-8">
        <div className="space-y-8">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatsCard
              title="Total Emails Verified"
              value={statsLoading ? "..." : stats?.totalVerified || 0}
              icon={Mail}
              iconColor="text-brand"
              iconBgColor="bg-blue-100"
              change={{
                value: "+12.3%",
                label: "from last month",
                positive: true
              }}
            />
            
            <StatsCard
              title="Valid Emails"
              value={statsLoading ? "..." : stats?.validEmails || 0}
              icon={CheckCircle}
              iconColor="text-green-600"
              iconBgColor="bg-green-100"
              change={{
                value: stats?.totalVerified ? `${((stats.validEmails / stats.totalVerified) * 100).toFixed(1)}%` : "0%",
                label: "validation rate"
              }}
            />
            
            <StatsCard
              title="Invalid Emails"
              value={statsLoading ? "..." : stats?.invalidEmails || 0}
              icon={XCircle}
              iconColor="text-red-500"
              iconBgColor="bg-red-100"
              change={{
                value: stats?.totalVerified ? `${((stats.invalidEmails / stats.totalVerified) * 100).toFixed(1)}%` : "0%",
                label: "invalid rate"
              }}
            />
            
            <StatsCard
              title="CSV Files Processed"
              value={statsLoading ? "..." : stats?.filesProcessed || 0}
              icon={FileText}
              iconColor="text-purple-600"
              iconBgColor="bg-purple-100"
              change={{
                value: "+5",
                label: "this week",
                positive: true
              }}
            />
          </div>

          {/* Recent Activity */}
          <Card>
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Recent Verification Jobs</h3>
            </div>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>File Name</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Total Emails</TableHead>
                    <TableHead>Valid</TableHead>
                    <TableHead>Invalid</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {jobsLoading ? (
                    [...Array(3)].map((_, i) => (
                      <TableRow key={i}>
                        <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                        <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      </TableRow>
                    ))
                  ) : recentJobs?.length ? (
                    recentJobs.map((job: any) => (
                      <TableRow key={job.id}>
                        <TableCell>
                          <div className="flex items-center">
                            <FileSpreadsheet className="text-green-600 mr-3 w-4 h-4" />
                            <span className="text-sm font-medium text-gray-900">
                              {job.originalFileName}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(job.status)}</TableCell>
                        <TableCell className="text-sm text-gray-900">{job.totalEmails || 0}</TableCell>
                        <TableCell className="text-sm text-green-600 font-medium">{job.validEmails || 0}</TableCell>
                        <TableCell className="text-sm text-red-500 font-medium">{job.invalidEmails || 0}</TableCell>
                        <TableCell className="text-sm text-gray-500">{formatDate(job.createdAt)}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {job.status === 'completed' && (
                              <>
                                <Link href={`/results?jobId=${job.id}`}>
                                  <Button variant="ghost" size="sm" className="text-brand hover:text-blue-600">
                                    View Results
                                  </Button>
                                </Link>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  className="text-brand hover:text-blue-600"
                                  onClick={() => window.open(`/api/jobs/${job.id}/export`, '_blank')}
                                >
                                  <Download className="w-4 h-4" />
                                </Button>
                              </>
                            )}
                            {job.status === 'processing' && (
                              <span className="text-sm text-gray-400">Processing...</span>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                        No verification jobs yet. 
                        <Link href="/upload">
                          <Button variant="link" className="text-brand">
                            Upload your first CSV file
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
