import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, Mail, Shield, Zap } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-brand rounded-lg flex items-center justify-center">
                <Mail className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">EmailVerify Pro</h1>
                <p className="text-sm text-gray-500">Professional Email Verification</p>
              </div>
            </div>
            <Button onClick={handleLogin} className="bg-brand hover:bg-blue-600">
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            Verify Email Addresses with Confidence
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Clean your email lists, improve deliverability, and boost your marketing campaigns 
            with our professional email verification service.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-brand hover:bg-blue-600 text-lg px-8 py-4"
          >
            Get Started Free
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose EmailVerify Pro?
            </h2>
            <p className="text-lg text-gray-600">
              Professional email verification made simple and reliable
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Zap className="text-brand text-xl" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Lightning Fast</h3>
                <p className="text-gray-600">
                  Process thousands of emails in minutes with our optimized verification engine.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Shield className="text-green-600 text-xl" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">99% Accuracy</h3>
                <p className="text-gray-600">
                  Advanced validation algorithms ensure the highest accuracy rates in the industry.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Mail className="text-purple-600 text-xl" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">CSV Support</h3>
                <p className="text-gray-600">
                  Easy bulk verification by uploading CSV files with instant results and exports.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-lg text-gray-600">
              Three simple steps to clean your email list
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-brand rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Upload CSV</h3>
              <p className="text-gray-600">
                Upload your CSV file containing email addresses that need verification.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-brand rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Verify</h3>
              <p className="text-gray-600">
                Our system processes and verifies each email address for validity and deliverability.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-brand rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Download</h3>
              <p className="text-gray-600">
                Download your cleaned email list with detailed verification results.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-brand">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Clean Your Email List?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Start with 1,000 free verification credits. No credit card required.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-white text-brand hover:bg-gray-100 text-lg px-8 py-4"
          >
            Get Started Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-center space-x-3">
            <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center">
              <Mail className="text-white text-sm" />
            </div>
            <span className="text-gray-900 font-semibold">EmailVerify Pro</span>
          </div>
          <p className="text-center text-gray-600 mt-4">
            © 2024 EmailVerify Pro. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
