import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Topbar } from "@/components/layout/topbar";
import { UploadZone } from "@/components/ui/upload-zone";
import { useLocation } from "wouter";

export default function Upload() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleFileUploaded = (jobId: number) => {
    // Navigate to results page to show the processing job
    navigate(`/results?jobId=${jobId}`);
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 p-8 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand mx-auto mb-4"></div>
            <p className="text-gray-600">Loading...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Topbar 
        title="Upload CSV" 
        description="Upload CSV files for email verification" 
      />

      <main className="flex-1 overflow-auto p-8">
        <UploadZone onFileUploaded={handleFileUploaded} />
      </main>
    </div>
  );
}
