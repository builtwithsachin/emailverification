import {
  users,
  verificationJobs,
  verificationResults,
  type User,
  type UpsertUser,
  type VerificationJob,
  type InsertVerificationJob,
  type VerificationResult,
  type InsertVerificationResult,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, count, sum } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserCredits(userId: string, credits: number): Promise<void>;

  // Verification job operations
  createVerificationJob(job: InsertVerificationJob): Promise<VerificationJob>;
  getVerificationJob(id: number): Promise<VerificationJob | undefined>;
  getVerificationJobsByUser(userId: string): Promise<VerificationJob[]>;
  updateVerificationJob(id: number, updates: Partial<VerificationJob>): Promise<void>;

  // Verification result operations
  createVerificationResults(results: InsertVerificationResult[]): Promise<void>;
  getVerificationResults(jobId: number, limit?: number, offset?: number): Promise<VerificationResult[]>;
  getVerificationResultsCount(jobId: number): Promise<number>;
  getVerificationResultsByStatus(jobId: number, isValid: boolean): Promise<VerificationResult[]>;

  // Dashboard statistics
  getUserStats(userId: string): Promise<{
    totalVerified: number;
    validEmails: number;
    invalidEmails: number;
    filesProcessed: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserCredits(userId: string, credits: number): Promise<void> {
    await db
      .update(users)
      .set({ credits, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }

  // Verification job operations
  async createVerificationJob(job: InsertVerificationJob): Promise<VerificationJob> {
    const [verificationJob] = await db
      .insert(verificationJobs)
      .values(job)
      .returning();
    return verificationJob;
  }

  async getVerificationJob(id: number): Promise<VerificationJob | undefined> {
    const [job] = await db
      .select()
      .from(verificationJobs)
      .where(eq(verificationJobs.id, id));
    return job;
  }

  async getVerificationJobsByUser(userId: string): Promise<VerificationJob[]> {
    return await db
      .select()
      .from(verificationJobs)
      .where(eq(verificationJobs.userId, userId))
      .orderBy(desc(verificationJobs.createdAt));
  }

  async updateVerificationJob(id: number, updates: Partial<VerificationJob>): Promise<void> {
    await db
      .update(verificationJobs)
      .set(updates)
      .where(eq(verificationJobs.id, id));
  }

  // Verification result operations
  async createVerificationResults(results: InsertVerificationResult[]): Promise<void> {
    if (results.length > 0) {
      await db.insert(verificationResults).values(results);
    }
  }

  async getVerificationResults(
    jobId: number,
    limit: number = 50,
    offset: number = 0
  ): Promise<VerificationResult[]> {
    return await db
      .select()
      .from(verificationResults)
      .where(eq(verificationResults.jobId, jobId))
      .limit(limit)
      .offset(offset)
      .orderBy(desc(verificationResults.verifiedAt));
  }

  async getVerificationResultsCount(jobId: number): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(verificationResults)
      .where(eq(verificationResults.jobId, jobId));
    return result.count;
  }

  async getVerificationResultsByStatus(
    jobId: number,
    isValid: boolean
  ): Promise<VerificationResult[]> {
    return await db
      .select()
      .from(verificationResults)
      .where(
        and(
          eq(verificationResults.jobId, jobId),
          eq(verificationResults.isValid, isValid)
        )
      );
  }

  // Dashboard statistics
  async getUserStats(userId: string): Promise<{
    totalVerified: number;
    validEmails: number;
    invalidEmails: number;
    filesProcessed: number;
  }> {
    const [stats] = await db
      .select({
        totalVerified: sum(verificationJobs.totalEmails),
        validEmails: sum(verificationJobs.validEmails),
        invalidEmails: sum(verificationJobs.invalidEmails),
        filesProcessed: count(verificationJobs.id),
      })
      .from(verificationJobs)
      .where(eq(verificationJobs.userId, userId));

    return {
      totalVerified: Number(stats.totalVerified) || 0,
      validEmails: Number(stats.validEmails) || 0,
      invalidEmails: Number(stats.invalidEmails) || 0,
      filesProcessed: Number(stats.filesProcessed) || 0,
    };
  }
}

export const storage = new DatabaseStorage();
