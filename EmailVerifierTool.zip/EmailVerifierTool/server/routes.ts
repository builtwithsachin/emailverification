import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import * as fs from "fs";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { CsvProcessor } from "./services/csvProcessor";
import { insertVerificationJobSchema } from "@shared/schema";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv')) {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard statistics
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard statistics" });
    }
  });

  // Get recent verification jobs
  app.get('/api/jobs/recent', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobs = await storage.getVerificationJobsByUser(userId);
      res.json(jobs.slice(0, 10)); // Return only recent 10 jobs
    } catch (error) {
      console.error("Error fetching recent jobs:", error);
      res.status(500).json({ message: "Failed to fetch recent jobs" });
    }
  });

  // Get all verification jobs (history)
  app.get('/api/jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobs = await storage.getVerificationJobsByUser(userId);
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching jobs:", error);
      res.status(500).json({ message: "Failed to fetch verification jobs" });
    }
  });

  // Upload and process CSV file
  app.post('/api/jobs/upload', isAuthenticated, upload.single('csvFile'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const file = req.file;
      const hasHeader = req.body.hasHeader === 'true';

      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Check user credits
      const user = await storage.getUser(userId);
      if (!user || (user.credits ?? 0) <= 0) {
        // Clean up uploaded file
        fs.unlinkSync(file.path);
        return res.status(400).json({ message: "Insufficient credits" });
      }

      // Create verification job
      const job = await storage.createVerificationJob({
        userId,
        fileName: file.filename,
        originalFileName: file.originalname,
        status: 'processing',
        hasHeader
      });

      // Process file asynchronously
      processFileAsync(job.id, file.path, hasHeader, userId);

      res.json({ 
        jobId: job.id,
        message: "File uploaded successfully. Processing started." 
      });
    } catch (error) {
      console.error("Error uploading file:", error);
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  // Get verification results for a specific job
  app.get('/api/jobs/:jobId/results', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobId = parseInt(req.params.jobId);
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 50;
      const offset = (page - 1) * limit;

      // Verify job belongs to user
      const job = await storage.getVerificationJob(jobId);
      if (!job || job.userId !== userId) {
        return res.status(404).json({ message: "Job not found" });
      }

      const results = await storage.getVerificationResults(jobId, limit, offset);
      const total = await storage.getVerificationResultsCount(jobId);

      res.json({
        results,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit)
        }
      });
    } catch (error) {
      console.error("Error fetching results:", error);
      res.status(500).json({ message: "Failed to fetch results" });
    }
  });

  // Export verification results
  app.get('/api/jobs/:jobId/export', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobId = parseInt(req.params.jobId);
      const validOnly = req.query.validOnly === 'true';

      // Verify job belongs to user
      const job = await storage.getVerificationJob(jobId);
      if (!job || job.userId !== userId) {
        return res.status(404).json({ message: "Job not found" });
      }

      const results = await storage.getVerificationResults(jobId, 999999, 0); // Get all results
      
      // Convert to EmailValidationResult format
      const validationResults = results.map(r => ({
        email: r.email,
        isValid: r.isValid,
        reason: r.reason || '',
        domain: r.domain || undefined
      }));

      const fileName = `export_${job.originalFileName}_${Date.now()}.csv`;
      const filePath = await CsvProcessor.exportResults(validationResults, fileName, validOnly);

      res.download(filePath, fileName, (err) => {
        if (err) {
          console.error("Error downloading file:", err);
        }
        // Clean up file after download
        fs.unlink(filePath, () => {});
      });
    } catch (error) {
      console.error("Error exporting results:", error);
      res.status(500).json({ message: "Failed to export results" });
    }
  });

  // Get job status
  app.get('/api/jobs/:jobId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobId = parseInt(req.params.jobId);

      const job = await storage.getVerificationJob(jobId);
      if (!job || job.userId !== userId) {
        return res.status(404).json({ message: "Job not found" });
      }

      res.json(job);
    } catch (error) {
      console.error("Error fetching job:", error);
      res.status(500).json({ message: "Failed to fetch job" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Async function to process uploaded file
async function processFileAsync(jobId: number, filePath: string, hasHeader: boolean, userId: string) {
  try {
    // Process the CSV file
    const processingResult = await CsvProcessor.processFile(filePath, hasHeader);
    
    // Update job with processing results
    await storage.updateVerificationJob(jobId, {
      status: 'completed',
      totalEmails: processingResult.totalRows,
      validEmails: processingResult.validationResults.filter(r => r.isValid).length,
      invalidEmails: processingResult.validationResults.filter(r => !r.isValid).length,
      creditsUsed: processingResult.totalRows,
      completedAt: new Date()
    });

    // Save verification results
    const verificationResults = processingResult.validationResults.map(result => ({
      jobId,
      email: result.email,
      isValid: result.isValid,
      reason: result.reason,
      domain: result.domain || null,
      mxRecord: result.mxRecord || null,
      deliverable: result.deliverable || false
    }));

    await storage.createVerificationResults(verificationResults);

    // Update user credits
    const user = await storage.getUser(userId);
    if (user) {
      const currentCredits = user.credits ?? 0;
      const newCredits = Math.max(0, currentCredits - processingResult.totalRows);
      await storage.updateUserCredits(userId, newCredits);
    }

    // Clean up uploaded file
    fs.unlink(filePath, () => {});

  } catch (error) {
    console.error("Error processing file:", error);
    
    // Update job status to failed
    await storage.updateVerificationJob(jobId, {
      status: 'failed',
      completedAt: new Date()
    });

    // Clean up uploaded file
    fs.unlink(filePath, () => {});
  }
}
