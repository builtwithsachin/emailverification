import * as fs from 'fs';
import * as path from 'path';
import { EmailValidator, type EmailValidationResult } from './emailValidator';

export interface CsvProcessingResult {
  totalRows: number;
  emails: string[];
  validationResults: EmailValidationResult[];
}

export class CsvProcessor {
  static async processFile(filePath: string, hasHeader: boolean = false): Promise<CsvProcessingResult> {
    try {
      const fileContent = await fs.promises.readFile(filePath, 'utf-8');
      const lines = fileContent.split('\n').filter(line => line.trim() !== '');
      
      let emails: string[] = [];
      let startIndex = hasHeader ? 1 : 0;
      
      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line) {
          // Parse CSV - simple implementation, handles basic CSV format
          const columns = this.parseCsvLine(line);
          if (columns.length > 0) {
            const email = columns[0].trim();
            if (email) {
              emails.push(email);
            }
          }
        }
      }

      // Remove duplicates
      emails = Array.from(new Set(emails));

      // Validate all emails
      const validationResults = await EmailValidator.validateEmails(emails);

      return {
        totalRows: emails.length,
        emails,
        validationResults
      };
    } catch (error) {
      throw new Error(`Failed to process CSV file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private static parseCsvLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current.trim());
    return result.map(field => field.replace(/^"(.*)"$/, '$1')); // Remove surrounding quotes
  }

  static async exportResults(
    results: EmailValidationResult[],
    fileName: string,
    validOnly: boolean = false
  ): Promise<string> {
    const filteredResults = validOnly 
      ? results.filter(r => r.isValid)
      : results;

    const csvContent = [
      'Email,Status,Reason,Domain,MX Record,Deliverable',
      ...filteredResults.map(result => 
        `"${result.email}","${result.isValid ? 'Valid' : 'Invalid'}","${result.reason}","${result.domain || ''}","${result.mxRecord || ''}","${result.deliverable ? 'Yes' : 'No'}"`
      )
    ].join('\n');

    const exportPath = path.join(process.cwd(), 'temp', fileName);
    
    // Ensure temp directory exists
    const tempDir = path.dirname(exportPath);
    if (!fs.existsSync(tempDir)) {
      await fs.promises.mkdir(tempDir, { recursive: true });
    }

    await fs.promises.writeFile(exportPath, csvContent, 'utf-8');
    return exportPath;
  }
}
