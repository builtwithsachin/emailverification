import * as dns from 'dns';
import { promisify } from 'util';

const resolveMx = promisify(dns.resolveMx);

export interface EmailValidationResult {
  email: string;
  isValid: boolean;
  reason: string;
  domain?: string;
  mxRecord?: string;
  deliverable?: boolean;
}

export class EmailValidator {
  private static readonly EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  private static readonly COMMON_INVALID_DOMAINS = new Set([
    'example.com',
    'test.com',
    'invalid.com',
    'fake.com',
    'dummy.com',
    'sample.com'
  ]);

  private static readonly DISPOSABLE_DOMAINS = new Set([
    '10minutemail.com',
    'guerrillamail.com',
    'tempmail.org',
    'throwaway.email',
    'mailinator.com'
  ]);

  static async validateEmail(email: string): Promise<EmailValidationResult> {
    const trimmedEmail = email.trim().toLowerCase();
    
    // Basic format validation
    if (!this.EMAIL_REGEX.test(trimmedEmail)) {
      return {
        email: trimmedEmail,
        isValid: false,
        reason: 'Invalid email format',
        deliverable: false
      };
    }

    const [localPart, domain] = trimmedEmail.split('@');
    
    // Check for common invalid patterns
    if (this.COMMON_INVALID_DOMAINS.has(domain)) {
      return {
        email: trimmedEmail,
        isValid: false,
        reason: 'Invalid test domain',
        domain,
        deliverable: false
      };
    }

    // Check for disposable email domains
    if (this.DISPOSABLE_DOMAINS.has(domain)) {
      return {
        email: trimmedEmail,
        isValid: false,
        reason: 'Disposable email domain',
        domain,
        deliverable: false
      };
    }

    // Check local part validity
    if (localPart.length > 64) {
      return {
        email: trimmedEmail,
        isValid: false,
        reason: 'Local part too long',
        domain,
        deliverable: false
      };
    }

    // Check domain validity
    if (domain.length > 255) {
      return {
        email: trimmedEmail,
        isValid: false,
        reason: 'Domain name too long',
        domain,
        deliverable: false
      };
    }

    // Check for consecutive dots
    if (trimmedEmail.includes('..')) {
      return {
        email: trimmedEmail,
        isValid: false,
        reason: 'Invalid consecutive dots',
        domain,
        deliverable: false
      };
    }

    // Check domain format
    if (!this.isValidDomain(domain)) {
      return {
        email: trimmedEmail,
        isValid: false,
        reason: 'Invalid domain format',
        domain,
        deliverable: false
      };
    }

    // Check MX record for deliverability
    const deliverabilityResult = await this.checkDeliverability(domain);
    
    return {
      email: trimmedEmail,
      isValid: deliverabilityResult.isValid,
      reason: deliverabilityResult.reason,
      domain,
      mxRecord: deliverabilityResult.mxRecord,
      deliverable: deliverabilityResult.deliverable
    };
  }

  private static isValidDomain(domain: string): boolean {
    // Basic domain validation
    const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    
    if (!domainRegex.test(domain)) {
      return false;
    }

    // Check if domain has at least one dot
    if (!domain.includes('.')) {
      return false;
    }

    // Check TLD validity (basic check)
    const parts = domain.split('.');
    const tld = parts[parts.length - 1];
    
    if (tld.length < 2 || tld.length > 6) {
      return false;
    }

    return true;
  }

  private static async checkDeliverability(domain: string): Promise<{
    isValid: boolean;
    reason: string;
    mxRecord?: string;
    deliverable: boolean;
  }> {
    try {
      // Check MX records for the domain
      const mxRecords = await resolveMx(domain);
      
      if (!mxRecords || mxRecords.length === 0) {
        return {
          isValid: false,
          reason: 'No MX record found',
          deliverable: false
        };
      }

      // Sort MX records by priority (lower number = higher priority)
      mxRecords.sort((a, b) => a.priority - b.priority);
      const primaryMx = mxRecords[0];

      return {
        isValid: true,
        reason: 'Valid email with MX record',
        mxRecord: primaryMx.exchange,
        deliverable: true
      };
    } catch (error) {
      // If DNS lookup fails, the domain doesn't exist or is unreachable
      return {
        isValid: false,
        reason: 'Domain not found or unreachable',
        deliverable: false
      };
    }
  }

  static async validateEmails(emails: string[]): Promise<EmailValidationResult[]> {
    // Process emails in batches to avoid overwhelming DNS servers
    const batchSize = 10;
    const results: EmailValidationResult[] = [];
    
    for (let i = 0; i < emails.length; i += batchSize) {
      const batch = emails.slice(i, i + batchSize);
      const batchPromises = batch.map(email => this.validateEmail(email));
      const batchResults = await Promise.all(batchPromises);
      results.push(...batchResults);
      
      // Small delay between batches to be respectful to DNS servers
      if (i + batchSize < emails.length) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    }
    
    return results;
  }
}
