# EmailVerify Pro - Email Verification Service

## Overview

EmailVerify Pro is a professional email verification service built as a full-stack web application. The application allows users to upload CSV files containing email addresses and perform bulk email verification to clean their email lists and improve deliverability for marketing campaigns.

## System Architecture

The application follows a modern full-stack architecture with clear separation between frontend and backend:

- **Frontend**: React-based single-page application using TypeScript
- **Backend**: Node.js/Express REST API server
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit OAuth integration
- **Build System**: Vite for frontend bundling and development
- **Styling**: Tailwind CSS with shadcn/ui component library

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Server**: Express.js with TypeScript
- **API Design**: RESTful API endpoints under `/api` prefix
- **File Upload**: Multer middleware for CSV file handling
- **Session Management**: Express sessions with PostgreSQL store
- **Database ORM**: Drizzle ORM with type-safe queries

### Database Schema
The application uses four main tables:
- **sessions**: Session storage for authentication (required by Replit Auth)
- **users**: User profiles with credit system
- **verification_jobs**: Email verification job tracking
- **verification_results**: Individual email verification results

### Authentication System
- **Provider**: Replit OAuth with OpenID Connect
- **Session Storage**: PostgreSQL-backed sessions with connect-pg-simple
- **Security**: HTTP-only cookies with secure flag in production
- **User Management**: Automatic user creation/updates on login

## Data Flow

1. **User Authentication**: Users authenticate via Replit OAuth
2. **File Upload**: Users upload CSV files through drag-and-drop interface
3. **Job Creation**: System creates verification job and parses CSV
4. **Email Processing**: Backend validates emails using built-in validation service
5. **Results Storage**: Validation results stored in database
6. **Data Presentation**: Frontend displays results with filtering and pagination
7. **Export**: Users can download processed results

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database driver optimized for serverless
- **drizzle-orm**: TypeScript ORM with strong type safety
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/***: Accessible UI component primitives
- **multer**: File upload handling middleware

### Development Dependencies
- **Vite**: Frontend build tool and development server
- **TypeScript**: Type checking and compilation
- **Tailwind CSS**: Utility-first CSS framework
- **PostCSS**: CSS processing and optimization

### Authentication Dependencies
- **openid-client**: OpenID Connect client for Replit OAuth
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

## Deployment Strategy

The application is designed for deployment on Replit with the following characteristics:

- **Environment**: Node.js with ES modules support
- **Database**: PostgreSQL (provisioned via Replit or external)
- **File Storage**: Local filesystem with uploads directory
- **Session Storage**: PostgreSQL-backed sessions
- **Static Assets**: Served via Express in production
- **Development**: Vite dev server with HMR support

### Build Process
1. Frontend builds to `dist/public` directory
2. Backend builds to `dist` directory using esbuild
3. Production server serves static files and API endpoints
4. Database migrations applied via Drizzle Kit

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Session encryption key
- `REPL_ID`: Replit environment identifier
- `ISSUER_URL`: OAuth issuer URL (defaults to Replit)

## Enhanced Email Verification Features

### Deliverability Validation
The email verification service now includes comprehensive deliverability checking:

- **DNS MX Record Validation**: Checks if the domain has valid mail exchange records
- **Real Domain Verification**: Ensures the domain actually exists and can receive emails
- **Enhanced Results Display**: Shows deliverability status and MX record information
- **Improved CSV Export**: Includes deliverability data in exported results

### Technical Implementation
- Uses Node.js DNS module for MX record lookups
- Batch processing (10 emails at a time) to respect DNS servers
- Stores deliverability data in database for historical tracking
- Updated verification table to display MX records and deliverability status

## Changelog

- July 02, 2025. Enhanced email verification with deliverability checking
- July 02, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.