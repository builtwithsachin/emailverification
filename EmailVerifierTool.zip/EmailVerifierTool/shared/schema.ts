import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  credits: integer("credits").default(1000),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Verification jobs table
export const verificationJobs = pgTable("verification_jobs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  fileName: varchar("file_name").notNull(),
  originalFileName: varchar("original_file_name").notNull(),
  status: varchar("status").notNull().default("pending"), // pending, processing, completed, failed
  totalEmails: integer("total_emails").default(0),
  validEmails: integer("valid_emails").default(0),
  invalidEmails: integer("invalid_emails").default(0),
  creditsUsed: integer("credits_used").default(0),
  hasHeader: boolean("has_header").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Email verification results table
export const verificationResults = pgTable("verification_results", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull().references(() => verificationJobs.id),
  email: varchar("email").notNull(),
  isValid: boolean("is_valid").notNull(),
  reason: varchar("reason"), // e.g., "valid", "invalid_format", "domain_not_found", etc.
  domain: varchar("domain"),
  mxRecord: varchar("mx_record"), // MX record for deliverability
  deliverable: boolean("deliverable").default(false), // true if email can receive mail
  verifiedAt: timestamp("verified_at").defaultNow(),
});

// Schema types and validations
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertVerificationJob = typeof verificationJobs.$inferInsert;
export type VerificationJob = typeof verificationJobs.$inferSelect;

export type InsertVerificationResult = typeof verificationResults.$inferInsert;
export type VerificationResult = typeof verificationResults.$inferSelect;

export const insertVerificationJobSchema = createInsertSchema(verificationJobs).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertVerificationResultSchema = createInsertSchema(verificationResults).omit({
  id: true,
  verifiedAt: true,
});
